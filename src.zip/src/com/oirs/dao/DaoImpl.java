package com.oirs.dao;

import java.sql.Connection;
import java.util.ArrayList;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;
import com.oirs.dbutil.DBConnector;

public class DaoImpl implements IDao {

	Connection con= null;
	@Override
	public boolean checkLogin(User user) {
		
		con=DBConnector.getConnected();
		
		return false;
	}

	@Override
	public boolean setRequisition(Requisition rb) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<Requisition> showCurrentRequisition() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Requisition> showRequisitionHistory() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
