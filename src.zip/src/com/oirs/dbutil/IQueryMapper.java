package com.oirs.dbutil;

public interface IQueryMapper {
	
	public static final String lOGIN_QUERY="select username,password from user where username=? and password =?";
	public static final String INSERT_INTO_REQUISITIOON = "INSERT INTO REQUISITION VALUES(?,?,?,?,?,?,?,?,?,?)";
	

}
